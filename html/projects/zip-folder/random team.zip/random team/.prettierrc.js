module.exports = {
  singleQuote: true,
  tabWidth: 2,
};
